# BazarHub Shopping Complex

A multi-tenant marketplace platform for a physical shopping complex: one
marketplace address where customers browse every shop in the building, and
each tenant (shop / e-commerce store / company / agency / showroom) gets their
own themed storefront and admin panel for a monthly subscription.

## The three layers

| Actor | What they get |
|---|---|
| **Complex owner** (platform admin) | Owner console at `/admin`: tenant list, suspend/reactivate, subscription plans, MRR and payment ledger |
| **Shop owner** (tenant) | Admin panel at `/dashboard`: products & services CRUD, order management, theme picker, team roles (owner / manager / staff), billing |
| **Customer** | Marketplace at `/`: shop directory, cross-complex product search, themed storefronts at `/shops/:slug`, guest cart + checkout, order tracking |

## Stack

- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS
- **Backend**: Hono + tRPC 11 (end-to-end typed)
- **Database**: MySQL via Drizzle ORM
- **Auth**: OAuth sign-in; the platform owner account is auto-promoted to
  `admin` (the complex owner)

## Core concepts

- **Tenancy** — shared database, `tenantId` on every tenant-owned row.
  Access is enforced server-side via `tenant_members` roles.
- **Themes** — token sets in `contracts/marketplace.ts` (Archive Mono,
  Lavender Market, Noir Showroom, Ledger Agency), applied to a storefront via
  CSS variables. A tenant switches themes instantly from their dashboard.
- **Catalog** — products (stock-tracked) and services (bookable) in one model.
- **Orders** — guest checkout; line items snapshotted; stock decremented
  atomically at order time; guests track by order number + email.
- **Billing** — monthly subscription per tenant (starter / pro / business),
  payment ledger, self-service payment recording and admin reconciliation.

## Develop

```bash
npm install
npm run db:push     # sync schema
npx tsx db/seed.ts  # demo shops + catalog
npm run dev         # http://localhost:3000
```

## Structure

```
api/            Hono server + tRPC routers (marketplace, tenant, orders, admin)
api/queries/    Drizzle query helpers
contracts/      Shared constants: themes, plans, business types
db/             schema.ts + seed.ts
src/pages/      Home, Products, Shop, ProductPage, CartPage, TrackOrder,
                Sell (onboarding), Dashboard (tenant admin), Admin (owner)
src/components/ SiteHeader, SiteFooter, ProductCard, ShopTheme
src/lib/        cart.ts (per-shop browser cart)
```

## Roadmap

- Payment-gateway integration for subscriptions and checkout
- Product image uploads (object storage)
- Subdomains / custom domains per tenant
- Customer accounts + order history
- Analytics for tenants
